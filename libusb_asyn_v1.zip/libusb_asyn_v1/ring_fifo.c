/*
Why this version is used everywhere

Advantages:
- no wrap conditions
- no head > tail logic
- safe arithmetic
- very easy to prove correct
- easy to use with DMA
That is why variants of this appear in:
Linux kernel
FreeBSD
FreeRTOS

and many UART/USB drivers.
THE PRINCIPLE:

Never wrap head and tail.
Let them grow forever.
Wrap only when accessing the array.
*/

#include "ring_fifo.h"
#include <string.h>
///!!!! len MUST BE power of 2, i.e. 16,32,64,128....
void ring_init(ring_t *r, uint8_t *buffer, uint32_t len)
{
    r->buf = buffer;
    r->buf_size = len;
    r->mask = len - 1;

    r->head = 0;
    r->tail = 0;
}

///available new data for read, that has not been consumed yet
uint32_t ring_available(ring_t *r)
{
    return r->head - r->tail;
}

//available data for write
uint32_t ring_free(ring_t *r)
{
    return r->buf_size - (r->head - r->tail);
}

//push block
uint32_t ring_push(ring_t *r, const uint8_t *src, uint32_t len)
{
    uint32_t free = ring_free(r);

    if (len > free)
        len = free;
        //index of an array rapping here.
        //It growing continously to high values (hardware wrap to 0 will be in anyway)
        //But the actual index of array = head & mask, or tail & mask.
        //So we care not about tail/head overflow, because of hardware wrap to 0,
        //instead or AND operation gives only values in the band 0...mask
        //So, the extra operations (tail/head) no need now - it increases performance
    uint32_t head_index = r->head & r->mask;

    uint32_t first_part = r->buf_size - head_index;

    if (first_part > len)
        first_part = len;

    memcpy(&r->buf[head_index], src, first_part);

    memcpy(&r->buf[0], src + first_part, len - first_part);

    r->head += len;

    return len;
}


//pop block
uint32_t ring_pop(ring_t *r, uint8_t *dst, uint32_t len)
{
    uint32_t available = ring_available(r);

    if (len > available)
        len = available;
        //index of an array rapping here.
        //It growing continously to high values (hardware wrap to 0 will be in anyway)
        //But the actual index of array = head & mask, or tail & mask.
        //So we care not about tail/head overflow, because of hardware wrap to 0,
        //instead or AND operation gives only values in the band 0...mask
        //So, the extra operations (tail/head) no need now - it increases performance
    uint32_t tail_index = r->tail & r->mask;

    uint32_t first_part = r->buf_size - tail_index;

    if (first_part > len)
        first_part = len;

    memcpy(dst, &r->buf[tail_index], first_part);

    memcpy(dst + first_part, &r->buf[0], len - first_part);

    r->tail += len;

    return len;
}

uint32_t ring_peek(ring_t *r, uint8_t *dst, uint32_t len)
{
    uint32_t available = ring_available(r);

    if (len > available)
        len = available;

    uint32_t tail_index = r->tail & r->mask;

    uint32_t first_part = r->buf_size - tail_index;

    if (first_part > len)
        first_part = len;

    memcpy(dst, &r->buf[tail_index], first_part);
    memcpy(dst + first_part, &r->buf[0], len - first_part);

    return len;
}

uint32_t ring_drain(ring_t *r, uint32_t len)
{
    uint32_t available = ring_available(r);

    if (len > available)
        len = available;
   //when you consume data through ring_peak() - it drains the tail - to have free space

    r->tail += len;

    return len;
}
