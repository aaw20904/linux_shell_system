const express = require("express");
const tokenController = require("./routes/token.js");
const registerController = require("./routes/register.js");
const dbLayer  = require("./dbLayer.js");
const fs = require("fs");
//tor this server
const pubkey = fs.readFileSync("./routes/public.pem","utf-8");
const privkey = fs.readFileSync("./routes/private.pem","utf-8");
//for a client
const client_pub = fs.readFileSync("./routes/client_public.pem","utf-8");
const client_key = fs.readFileSync("./routes/client_key.pem","utf-8");

//const bodyParser = require("body-parser");
  const app = express();


let dbL = new dbLayer();
registerController.dbLayer = dbL;
tokenController.dbLayer = dbL;
tokenController.secrets={pubkey, privkey, client_pub, client_key}

 

async function main() {
    let dbL = new dbLayer();
    await dbL.connectToDb();

    app.use(express.urlencoded({ extended: false }))
    app.use(express.json({extended:true}));
    app.use("/register", registerController);
    app.use ("/token", tokenController);
     //await dbL.addNewUser("wasya","1345");
    //let u_info = await dbL.getUserById(1);
   // await dbL.writeRefreshToken(u_info.user_id, (Math.random() * 0xffff) | 0)
   // await dbL.disconnectFromDb();
   app.listen(3000, ()=>console.log("the auth serrver listen 3000"));
}

main();




