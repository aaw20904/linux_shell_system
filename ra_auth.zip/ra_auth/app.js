const express = require("express");
const tokenController = require("./routes/token.js");
const registerController = require("./routes/register.js");
const dbLayer  = require("./dbLayer.js");
//const bodyParser = require("body-parser");
  const app = express();


let dbL = new dbLayer();
registerController.dbLayer = dbL;

 

async function main() {
    let dbL = new dbLayer();
    await dbL.connectToDb();

    app.use(express.urlencoded({ extended: false }))
    app.use(express.json({extended:true}));
    app.use("/register", registerController);
     //await dbL.addNewUser("wasya","1345");
    //let u_info = await dbL.getUserById(1);
   // await dbL.writeRefreshToken(u_info.user_id, (Math.random() * 0xffff) | 0)
   // await dbL.disconnectFromDb();
   app.listen(3000, ()=>console.log("the auth serrver listen 3000"));
}

main();




