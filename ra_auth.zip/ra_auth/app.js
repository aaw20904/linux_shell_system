const express = require("express");
const tokenController = require("./routes/token.js");
const registerController = require("./routes/register.js");
const dbLayer  = require("./dbLayer.js");
const bodyParser = require("body-parser");

const app = express();

app.use(bodyParser.urlencoded({ extended: false }))
app.use("/register", registerController);

async function main() {
    let dbL = new dbLayer();
    await dbL.connectToDb();
  
    let u_info = await dbL.getUserById(4);
    await dbL.writeRefreshToken(u_info.user_id, (Math.random() * 0xffff) | 0)
    await dbL.disconnectFromDb();
}

app.listen(3000, ()=>console.log("the auth serrver listen 3000"));


