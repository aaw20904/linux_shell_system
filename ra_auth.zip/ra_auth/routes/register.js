const express = require('express');
const router = express.Router();
const bcrypt = require("bcrypt")


// middleware that is specific to this router
router.use((req, res, next) => {
  console.log('Time: ', Date.now())
  next()
})

router.post("/newuser",async (req, res)=>{
    //user_name, user_password
    let hashedPassword = await bcrypt.hash(req.body.user_password, 50);
    // Load hash from your password DB.

   let reverse = await  bcrypt.compare(req.body.user_password, hashedPassword);
   res.json({reverse});
    
})

module.exports = router
