const express = require('express');
const router = express.Router();
const bcrypt = require("bcrypt");
const jsonwebtoken = require("jsonwebtoken");
const fs = require("fs");
const crypto = require("crypto")




router.post("/newtoken", async (req, res)=>{
 
 //a) Is a token  valid?
 let decodedRefreshToken;
 let receivedRefreshToken = req.body.token;
 
    try{
         decodedRefreshToken = await new Promise((resolve, reject) => {
            jsonwebtoken.verify(req.body.token, router.secrets.pubkey,{algorithm:  "RS256"},(err, decoded)=>{
                    if(err){
                        reject(err);
                    } else {
                        resolve(decoded);
                    }
            })
        });
      //  res.status(200).json({result, expiration_result: new Date(result.exp*1000).toString()});

    }catch(e){
        //when a token isn`t valid - revoke 
        res.status(409).json({error:e});
    }
//2) Is a received token equals to the old?
    //get user info
    let userInfo = await router.dbLayer.getUserById( decodedRefreshToken.user_id); 
    if(!userInfo){
        //when not found
        res.status(404).json({error:"empty"});
        return;
    }
    //compare an old and a received tokens
    if( crypto.timingSafeEqual(userInfo.refresh_token,  receivedRefreshToken) ) {
        res.status(409).json({error:"reuse"});
        return;
    }
//3) generate refresh token

    let newRefreshToken, newAccessToken;
    try {

        newRefreshToken = await new Promise((resolve, reject) => {
                    jsonwebtoken.sign({user_id: decodedRefreshToken.user_id, exp: Math.floor(Date.now() / 1000) + (60 * 60),}, router.secrets.privkey, {algorithm:  "RS256"},(err, encoded)=>{
                        if (err) {
                            reject(err.message);
                        } else {
                            resolve(encoded);
                        }
                    });
                });
       //4) new access token
         newAccessToken = await new Promise((resolve, reject) => {
                    jsonwebtoken.sign({user_id: userInfo.user_id, exp: Math.floor(Date.now() / 1000) + (60 * 60),}, router.secrets.client_key, {algorithm:  "RS256"},(err, encoded)=>{
                        if (err) {
                            reject(err.message);
                        } else {
                            resolve(encoded);
                        }
                    });
                });

    } catch(e){
        ///when token isn`t valid - revoke refresh
        res.status(500).json({err:e});
    }
    //5) save received token 
    await router.dbLayer.writeRefreshToken(userInfo.user_id, receivedRefreshToken);
    //6) respond to the client with new tokens:
    res.status(200).json({access_token:newAccessToken, refresh_token:newRefreshToken}); 


})


router.post("/test", async (req, res, next)=>{
    try{
    newRefreshToken = await new Promise((resolve, reject) => {
                    jsonwebtoken.sign({user_id: 5, exp: Math.floor(Date.now() / 1000) + (60 * 60),}, router.secrets.privkey, {algorithm:  "RS256"},(err, encoded)=>{
                        if (err) {
                            reject(err.message);
                        } else {
                            resolve(encoded);
                        }
                    });
                });
    res.status(200).json({token: newRefreshToken});
    }catch(e){
        res.json(e);
    }

})

module.exports=router