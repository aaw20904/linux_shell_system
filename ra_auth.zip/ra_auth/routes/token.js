const express = require('express');
const router = express.Router();
const bcrypt = require("bcrypt");
const jsonwebtoken = require("jsonwebtoken");
const SERVER_SECRET = "srvsecret123";



router.post("/updatetoken", (req, res)=>{
 //1)read old refresh token from the DB
 //a) validate token
 //b) checking - has the token been reused?
 //c) generating new
 

})
