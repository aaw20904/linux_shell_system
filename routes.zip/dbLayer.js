/******* database layer
rft.users = {
    user_id: AUTOINC PK INT NOT_NULL,
    user_name: VARCHR(64) NULL INDEXED UNIQUE,
    user_password: BLOB NULL,
    refresh_token: BLOB NULL
}
********/
const mysql = require('mysql2'); //database mamnagement system MySQL




class dbWrap {

    constructor() {
        this.connectionDB = mysql.createConnection({
            user: 'root',
            password: '65535258',
            host: 'localhost',
            database: 'rft',	  
         });

    }

    async connectToDb () {

        ///template of the table
        const table_template = "CREATE TABLE if not exists `rft`.`users` ("+
        "`user_id` INT NOT NULL AUTO_INCREMENT,"+
        "`user_name` VARCHAR(64) NULL,"+
        " `user_password` BLOB NULL,"+
        " `refresh_token` BLOB NULL,"+
        "PRIMARY KEY (`user_id`),"+
        "  UNIQUE INDEX `user_name_UNIQUE` (`user_name` ASC) VISIBLE);";

        await new Promise((resolve, reject) => {
            this.connectionDB.connect(function(err) {
                if (err) {
                    //handle an error
                    console.error('error connecting: ' + err.stack);
                    reject(err)
                } else {
                    resolve();
                }
            })


        });

        return new Promise((resolve, reject) => {
            this.connectionDB.query(table_template, (err, rows)=>{
                if (err) {
                    reject(err);
                } else {
                    resolve(true);
                }
            })
        });
    }

    async disconnectFromDb(){

        return new Promise((resolve, reject) => {
                this.connectionDB.end((err)=>{
                if(err){
                    reject(err)
                }else {
                    resolve(true);
                }
                })
        });
      
    }

    async isUserExists (name) {
        return new Promise((resolve, reject) => {
            this.connectionDB.query(`SELECT user_id FROM users WHERE user_name='${name}'`,(err, rows)=>{
                if(err){
                    reject(err);
                } else {
                    if (rows.length > 0) {
                        return false;
                    } else {
                        return true;
                    }
                }
            })
        });
    }

    async addNewUser (name, password) {
        await new Promise((resolve, reject) => {
              this.connectionDB.query(`INSERT INTO users (user_name, user_password) VALUES (?,?)`,[name, password], (err, rows)=>{
                if(err){
                    if (err.errno === 1062) {
                        err.userExists = true;
                    } 
                    reject(err);
                }else{
                    resolve(rows);
                }
              })
        });

        return new Promise((resolve, reject) => {
            this.connectionDB.query(`SELECT LAST_INSERT_ID();`,(err, rows)=>{
                if(err){
                    reject(err)
                }else{
                    resolve(rows[0]["LAST_INSERT_ID()"])
                }
            })
        });
    }

    async getUserByName (name) {
        return new Promise((resolve, reject) => {
            this.connectionDB.query(`SELECT* FROM users WHERE user_name='${name}'`, (err, rows)=>{
                if(err){
                    reject(err)
                }else{
                    resolve(rows.length === 0  ? false : rows[0]);
                }
            })
        });
    }

 async getUserById (user_id) {
        return new Promise((resolve, reject) => {
            this.connectionDB.query(`SELECT* FROM users WHERE user_id='${user_id}'`, (err, rows)=>{
                if(err){
                    reject(err)
                }else{
                    resolve(rows.length === 0  ? false : rows[0]);
                }
            })
        });
    }

    async writeRefreshToken (user_id, token) {
        return new Promise((resolve, reject) => {
            this.connectionDB.query(`UPDATE users SET refresh_token=? WHERE user_id=${user_id}`,token, (err, rows)=>{
                if (err){
                    console.log(err.sql);
                    reject(err)
                } else {
                    resolve(rows);
                }
            })
        });
    }
}


 module.exports = dbWrap





 



